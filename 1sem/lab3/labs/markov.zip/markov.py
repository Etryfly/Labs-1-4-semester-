import string
rules = []
rul_t = open("rules.txt")
for stri in rul_t:
    i = False
    if "->." in stri:
        i = True
    l_s = stri.strip(string.whitespace).split("->")
    n1 = l_s[0]
    n2 = l_s[1].strip(".")
    rules.append((n1, n2, i))
strm = input()
while True:
    c = True
    b = False
    for rule in rules:
        ch = strm.find(rule[0])
        if ch == -1:
            continue
        else:
            c = False
            strm = strm[0:ch] + rule[1] + strm[ch+len(rule[0]):]
            print(strm)
            if rule[2]:
                b = True
                break
            else:
                break
    if b or c:
        break

    
    
    
    
